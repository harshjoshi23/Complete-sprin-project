package com.training.resources;

import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import com.training.model.Student;

import jakarta.ws.rs.*;


@Path("/api/students")
public class StudentResource {
	@Produces(value = MediaType.APPLICATION_JSON)
	@GET
	public Student getStudent() {
		return new Student(1010, "Ramesh", 98);
	}
	
}
